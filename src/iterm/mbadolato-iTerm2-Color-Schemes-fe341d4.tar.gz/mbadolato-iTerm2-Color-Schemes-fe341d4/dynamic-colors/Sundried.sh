#!/bin/sh
# Sundried
printf "\033]4;0;#302b2a;1;#a7463d;2;#587744;3;#9d602a;4;#485b98;5;#864651;6;#9c814f;7;#c9c9c9;8;#4d4e48;9;#aa000c;10;#128c21;11;#fc6a21;12;#7999f7;13;#fd8aa1;14;#fad484;15;#ffffff\007"
printf "\033]10;#c9c9c9;#1a1818;#ffffff\007"
printf "\033]17;#302b2a\007"
printf "\033]19;#c9c9c9\007"
printf "\033]5;0;#ffffff\007"
