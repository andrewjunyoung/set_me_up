#!/bin/sh
# Mirage
printf "\033]4;0;#011627;1;#ff9999;2;#85cc95;3;#ffd700;4;#7fb5ff;5;#ddb3ff;6;#21c7a8;7;#ffffff;8;#575656;9;#ff9999;10;#85cc95;11;#ffd700;12;#7fb5ff;13;#ddb3ff;14;#85cc95;15;#ffffff\007"
printf "\033]10;#a6b2c0;#1b2738;#ddb3ff\007"
printf "\033]17;#273951\007"
printf "\033]19;#d3dbe5\007"
printf "\033]5;0;#ffb38c\007"
