#!/bin/sh
# SeaShells
printf "\033]4;0;#17384c;1;#d15123;2;#027c9b;3;#fca02f;4;#1e4950;5;#68d4f1;6;#50a3b5;7;#deb88d;8;#434b53;9;#d48678;10;#628d98;11;#fdd39f;12;#1bbcdd;13;#bbe3ee;14;#87acb4;15;#fee4ce\007"
printf "\033]10;#deb88d;#09141b;#fca02f\007"
printf "\033]17;#1e4962\007"
printf "\033]19;#fee4ce\007"
printf "\033]5;0;#ffe4cc\007"
