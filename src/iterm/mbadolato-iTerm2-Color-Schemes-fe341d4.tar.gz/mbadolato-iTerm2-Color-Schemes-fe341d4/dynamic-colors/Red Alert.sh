#!/bin/sh
# Red Alert
printf "\033]4;0;#000000;1;#d62e4e;2;#71be6b;3;#beb86b;4;#489bee;5;#e979d7;6;#6bbeb8;7;#d6d6d6;8;#262626;9;#e02553;10;#aff08c;11;#dfddb7;12;#65aaf1;13;#ddb7df;14;#b7dfdd;15;#ffffff\007"
printf "\033]10;#ffffff;#762423;#ffffff\007"
printf "\033]17;#073642\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ff9c44\007"
