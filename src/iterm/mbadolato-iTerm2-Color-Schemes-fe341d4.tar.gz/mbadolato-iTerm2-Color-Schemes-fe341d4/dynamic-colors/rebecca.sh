#!/bin/sh
# rebecca
printf "\033]4;0;#12131e;1;#dd7755;2;#04dbb5;3;#f2e7b7;4;#7aa5ff;5;#bf9cf9;6;#56d3c2;7;#e4e3e9;8;#666699;9;#ff92cd;10;#01eac0;11;#fffca8;12;#69c0fa;13;#c17ff8;14;#8bfde1;15;#f4f2f9\007"
printf "\033]10;#e8e6ed;#292a44;#b89bf9\007"
printf "\033]17;#663399\007"
printf "\033]19;#f4f2f9\007"
printf "\033]5;0;#ccccff\007"
