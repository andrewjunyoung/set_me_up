#!/bin/sh
# BlulocoDark
printf "\033]4;0;#4a505d;1;#f81141;2;#23974a;3;#fd7e57;4;#285bff;5;#8c62fd;6;#366f9a;7;#ccd5e5;8;#61697a;9;#fc4a6d;10;#37bd58;11;#f6be48;12;#199ffd;13;#fc58f6;14;#50acae;15;#ffffff\007"
printf "\033]10;#abb2bf;#1e2127;#fec309\007"
printf "\033]17;#2f3441\007"
printf "\033]19;#abb2bf\007"
printf "\033]5;0;#ffffff\007"
