#!/bin/sh
# ForestBlue
printf "\033]4;0;#333333;1;#f8818e;2;#92d3a2;3;#1a8e63;4;#8ed0ce;5;#5e468c;6;#31658c;7;#e2d8cd;8;#3d3d3d;9;#fb3d66;10;#6bb48d;11;#30c85a;12;#39a7a2;13;#7e62b3;14;#6096bf;15;#e2d8cd\007"
printf "\033]10;#e2d8cd;#051519;#9e9ecb\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
