#!/bin/sh
# synthwave-everything
printf "\033]4;0;#fefefe;1;#f97e72;2;#72f1b8;3;#fede5d;4;#6d77b3;5;#c792ea;6;#f772e0;7;#fefefe;8;#fefefe;9;#f88414;10;#72f1b8;11;#fff951;12;#36f9f6;13;#e1acff;14;#f92aad;15;#fefefe\007"
printf "\033]10;#f0eff1;#2a2139;#72f1b8\007"
printf "\033]17;#181521\007"
printf "\033]19;#f0eff1\007"
printf "\033]5;0;#f0eff1\007"
