#!/bin/sh
# Desert
printf "\033]4;0;#4d4d4d;1;#ff2b2b;2;#98fb98;3;#f0e68c;4;#cd853f;5;#ffdead;6;#ffa0a0;7;#f5deb3;8;#555555;9;#ff5555;10;#55ff55;11;#ffff55;12;#87ceff;13;#ff55ff;14;#ffd700;15;#ffffff\007"
printf "\033]10;#ffffff;#333333;#00ff00\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffd700\007"
