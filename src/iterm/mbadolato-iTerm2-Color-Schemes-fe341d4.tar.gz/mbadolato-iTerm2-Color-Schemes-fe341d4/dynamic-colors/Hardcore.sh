#!/bin/sh
# Hardcore
printf "\033]4;0;#1b1d1e;1;#f92672;2;#a6e22e;3;#fd971f;4;#66d9ef;5;#9e6ffe;6;#5e7175;7;#ccccc6;8;#505354;9;#ff669d;10;#beed5f;11;#e6db74;12;#66d9ef;13;#9e6ffe;14;#a3babf;15;#f8f8f2\007"
printf "\033]10;#a0a0a0;#121212;#bbbbbb\007"
printf "\033]17;#453b39\007"
printf "\033]19;#b6bbc0\007"
printf "\033]5;0;#ffffff\007"
