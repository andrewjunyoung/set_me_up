#!/bin/sh
# lovelace
printf "\033]4;0;#282a36;1;#f37f97;2;#5adecd;3;#f2a272;4;#8897f4;5;#c574dd;6;#79e6f3;7;#fdfdfd;8;#414458;9;#ff4971;10;#18e3c8;11;#ff8037;12;#556fff;13;#b043d1;14;#3fdcee;15;#bebec1\007"
printf "\033]10;#fdfdfd;#1d1f28;#c574dd\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
