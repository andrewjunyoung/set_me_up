#!/bin/sh
# Seafoam Pastel
printf "\033]4;0;#757575;1;#825d4d;2;#728c62;3;#ada16d;4;#4d7b82;5;#8a7267;6;#729494;7;#e0e0e0;8;#8a8a8a;9;#cf937a;10;#98d9aa;11;#fae79d;12;#7ac3cf;13;#d6b2a1;14;#ade0e0;15;#e0e0e0\007"
printf "\033]10;#d4e7d4;#243435;#57647a\007"
printf "\033]17;#ffffff\007"
printf "\033]19;#9e8b13\007"
printf "\033]5;0;#648890\007"
