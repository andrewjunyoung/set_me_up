#!/bin/sh
# Vaughn
printf "\033]4;0;#25234f;1;#705050;2;#60b48a;3;#dfaf8f;4;#5555ff;5;#f08cc3;6;#8cd0d3;7;#709080;8;#709080;9;#dca3a3;10;#60b48a;11;#f0dfaf;12;#5555ff;13;#ec93d3;14;#93e0e3;15;#ffffff\007"
printf "\033]10;#dcdccc;#25234f;#ff5555\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ff5e7d\007"
