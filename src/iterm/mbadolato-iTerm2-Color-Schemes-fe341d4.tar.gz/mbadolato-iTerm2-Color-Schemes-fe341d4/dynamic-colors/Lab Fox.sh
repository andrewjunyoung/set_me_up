#!/bin/sh
# Lab Fox
printf "\033]4;0;#2e2e2e;1;#fc6d26;2;#3eb383;3;#fca121;4;#db3b21;5;#380d75;6;#6e49cb;7;#ffffff;8;#464646;9;#ff6517;10;#53eaa8;11;#fca013;12;#db501f;13;#441090;14;#7d53e7;15;#ffffff\007"
printf "\033]10;#ffffff;#2e2e2e;#7f7f7f\007"
printf "\033]17;#cb392e\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
