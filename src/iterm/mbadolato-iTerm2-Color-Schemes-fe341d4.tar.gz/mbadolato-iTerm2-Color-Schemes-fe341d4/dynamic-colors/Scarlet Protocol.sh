#!/bin/sh
# Scarlet Protocol
printf "\033]4;0;#101116;1;#ff0051;2;#00dc84;3;#faf945;4;#0271b6;5;#ca30c7;6;#00c5c7;7;#c7c7c7;8;#686868;9;#ff6e67;10;#5ffa68;11;#fffc67;12;#6871ff;13;#bd35ec;14;#60fdff;15;#ffffff\007"
printf "\033]10;#e41951;#1c153d;#76ff9f\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#f5f443\007"
