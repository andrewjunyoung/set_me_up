#!/bin/sh
# Tango Half Adapted
printf "\033]4;0;#000000;1;#ff0000;2;#4cc300;3;#e2c000;4;#008ef6;5;#a96cb3;6;#00bdc3;7;#e0e5db;8;#797d76;9;#ff0013;10;#8af600;11;#ffec00;12;#76bfff;13;#d898d1;14;#00f6fa;15;#f4f4f2\007"
printf "\033]10;#000000;#ffffff;#000000\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#000000\007"
