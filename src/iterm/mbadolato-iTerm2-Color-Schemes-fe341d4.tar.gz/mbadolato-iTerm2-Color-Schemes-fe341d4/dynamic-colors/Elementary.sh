#!/bin/sh
# Elementary
printf "\033]4;0;#242424;1;#d71c15;2;#5aa513;3;#fdb40c;4;#063b8c;5;#e40038;6;#2595e1;7;#efefef;8;#4b4b4b;9;#fc1c18;10;#6bc219;11;#fec80e;12;#0955ff;13;#fb0050;14;#3ea8fc;15;#8c00ec\007"
printf "\033]10;#efefef;#181818;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
