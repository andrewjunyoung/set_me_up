#!/bin/sh
# Twilight
printf "\033]4;0;#141414;1;#c06d44;2;#afb97a;3;#c2a86c;4;#44474a;5;#b4be7c;6;#778385;7;#ffffd4;8;#262626;9;#de7c4c;10;#ccd88c;11;#e2c47e;12;#5a5e62;13;#d0dc8e;14;#8a989b;15;#ffffd4\007"
printf "\033]10;#ffffd4;#141414;#ffffff\007"
printf "\033]17;#313131\007"
printf "\033]19;#ffffd4\007"
printf "\033]5;0;#ffffd4\007"
