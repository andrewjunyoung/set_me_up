#!/bin/sh
# Github
printf "\033]4;0;#3e3e3e;1;#970b16;2;#07962a;3;#f8eec7;4;#003e8a;5;#e94691;6;#89d1ec;7;#ffffff;8;#666666;9;#de0000;10;#87d5a2;11;#f1d007;12;#2e6cba;13;#ffa29f;14;#1cfafe;15;#ffffff\007"
printf "\033]10;#3e3e3e;#f4f4f4;#3f3f3f\007"
printf "\033]17;#a9c1e2\007"
printf "\033]19;#535353\007"
printf "\033]5;0;#c95500\007"
