#!/bin/sh
# Seti
printf "\033]4;0;#323232;1;#c22832;2;#8ec43d;3;#e0c64f;4;#43a5d5;5;#8b57b5;6;#8ec43d;7;#eeeeee;8;#323232;9;#c22832;10;#8ec43d;11;#e0c64f;12;#43a5d5;13;#8b57b5;14;#8ec43d;15;#ffffff\007"
printf "\033]10;#cacecd;#111213;#e3bf21\007"
printf "\033]17;#303233\007"
printf "\033]19;#cacecd\007"
printf "\033]5;0;#cacecd\007"
