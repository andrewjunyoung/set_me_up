#!/bin/sh
# OneHalfDark
printf "\033]4;0;#282c34;1;#e06c75;2;#98c379;3;#e5c07b;4;#61afef;5;#c678dd;6;#56b6c2;7;#dcdfe4;8;#282c34;9;#e06c75;10;#98c379;11;#e5c07b;12;#61afef;13;#c678dd;14;#56b6c2;15;#dcdfe4\007"
printf "\033]10;#dcdfe4;#282c34;#a3b3cc\007"
printf "\033]17;#474e5d\007"
printf "\033]19;#dcdfe4\007"
printf "\033]5;0;#abb2bf\007"
