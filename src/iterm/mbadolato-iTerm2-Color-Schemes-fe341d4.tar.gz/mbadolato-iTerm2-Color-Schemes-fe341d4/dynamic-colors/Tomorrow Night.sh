#!/bin/sh
# Tomorrow Night
printf "\033]4;0;#000000;1;#cc6666;2;#b5bd68;3;#f0c674;4;#81a2be;5;#b294bb;6;#8abeb7;7;#ffffff;8;#000000;9;#cc6666;10;#b5bd68;11;#f0c674;12;#81a2be;13;#b294bb;14;#8abeb7;15;#ffffff\007"
printf "\033]10;#c5c8c6;#1d1f21;#c5c8c6\007"
printf "\033]17;#373b41\007"
printf "\033]19;#c5c8c6\007"
printf "\033]5;0;#c5c8c6\007"
